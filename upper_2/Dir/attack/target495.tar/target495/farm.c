/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_446()
{
    return 2425393240U;
}

void setval_190(unsigned *p)
{
    *p = 3247476824U;
}

void setval_343(unsigned *p)
{
    *p = 2425393224U;
}

void setval_289(unsigned *p)
{
    *p = 3281031256U;
}

unsigned getval_128()
{
    return 3347663084U;
}

unsigned getval_342()
{
    return 2462550344U;
}

void setval_183(unsigned *p)
{
    *p = 3284633928U;
}

void setval_368(unsigned *p)
{
    *p = 3251079496U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_280(unsigned x)
{
    return x + 3286272329U;
}

void setval_465(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_443()
{
    return 2464188744U;
}

unsigned addval_299(unsigned x)
{
    return x + 2462304905U;
}

unsigned addval_398(unsigned x)
{
    return x + 3223898761U;
}

unsigned getval_497()
{
    return 2430634440U;
}

void setval_439(unsigned *p)
{
    *p = 3373848201U;
}

unsigned getval_333()
{
    return 3525367433U;
}

unsigned getval_106()
{
    return 3281305993U;
}

unsigned addval_301(unsigned x)
{
    return x + 3398029979U;
}

unsigned getval_388()
{
    return 3286276424U;
}

unsigned addval_194(unsigned x)
{
    return x + 2430634312U;
}

unsigned getval_224()
{
    return 3375939979U;
}

unsigned addval_378(unsigned x)
{
    return x + 3229927945U;
}

void setval_236(unsigned *p)
{
    *p = 2429192238U;
}

void setval_199(unsigned *p)
{
    *p = 3375942285U;
}

unsigned addval_396(unsigned x)
{
    return x + 3229144713U;
}

unsigned getval_399()
{
    return 3525886345U;
}

void setval_163(unsigned *p)
{
    *p = 3680553609U;
}

unsigned addval_162(unsigned x)
{
    return x + 2430634344U;
}

void setval_148(unsigned *p)
{
    *p = 3524840073U;
}

unsigned addval_476(unsigned x)
{
    return x + 3523789193U;
}

unsigned addval_261(unsigned x)
{
    return x + 3223372169U;
}

unsigned getval_158()
{
    return 3525891721U;
}

unsigned addval_353(unsigned x)
{
    return x + 3378561417U;
}

unsigned addval_145(unsigned x)
{
    return x + 2730738073U;
}

unsigned getval_381()
{
    return 3375945353U;
}

unsigned getval_352()
{
    return 3268839889U;
}

unsigned getval_204()
{
    return 2464188744U;
}

unsigned getval_212()
{
    return 3224950441U;
}

void setval_314(unsigned *p)
{
    *p = 3372799627U;
}

unsigned getval_330()
{
    return 3223896457U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
